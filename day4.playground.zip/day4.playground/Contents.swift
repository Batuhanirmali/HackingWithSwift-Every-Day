import UIKit

//For loops

let count = 1...10

for number in count {
    print("number is \(number)")
}

let albums = ["Red", "1989", "Reputation"]

    for album in albums {
        print("\(album) is on apple music")
    }

for _ in 1...5 {
    print("play")
}

for number in [2, 3, 5] {
    print("\(number) is a prime number.")
}

//While loops

var number2 = 1

while number2 <= 20 {
    print(number2)
    number2 += 1
}

print("ready or not, here I come")

var countdown: Int = 5
repeat {
    print("\(countdown)...")
    countdown -= 1
} while countdown > 0
print("Lift off!")

var bagels = 5
repeat {
    print("Someone ate a bagel!")
    bagels -= 1
} while bagels > 0

// Repeat loops

var number32 = 1

repeat {
    print(number32)
    number32 += 1
} while number32 <= 20
            print("ready or not , here I come")

while false {
    print("This is false")
}
var bagels11 = 5
repeat {
    print("Someone ate a bagel!")
    bagels11 -= 1
} while bagels11 > 0

//Exiting loops


var people3 = 2
while people3 < 10 {
    people3 += 2
    if people3 == 10 {
        print("We got 10 people.")
    }
}

for i1 in 1...15 {
    if i1 % 3 == 0 {
        if i1 % 5 == 0 {
            print("\(i1) is a multiple of both 3 and 5.")
        }
    }
}

//Exiting multiple loops

outerloop: for i4 in 1...10 {
    for j4 in 1...10  {
        let product = i4 * j4
        print("\(i4) * \(j4) is \(product)")
        if product == 50 {
            print("it's a bulleyes")
            break outerloop
        }
    }
}

//Skipping items

for i5 in 1...10 {
    if i5 % 2 == 1{
        continue
    }
    print(i5)
}

let fibonacci = [1, 1, 2, 3, 5, 8, 13, 21]
var position = 0
while position <= 7 {
    let value = fibonacci[position]
    position += 1
    if value < 2 {
       continue
    }
    print("Fibonacci number \(position) is \(value)")
}

for square313 in [4, 9, 16, 25, 36] {
    if square313 >= 25 {
        continue
    } else {
        print("What's the square root of \(square313)?")
    }
}

//Infinite loops

var counter = 0

while true {
    print(" ")
    counter += 1

    if counter == 273 {
        break
    }
}



