import UIKit

// Variables
var str = "hello"
str = "good by"

// Strings an integers
var name = "Hello, my friend"
var age = 38
var population = 8_000_000

// Multi-Line strings

var str1 = """

 This goes over multiple lines

"""

var str2 = """

 This goes / over / multiple lines

"""
// Doubles and booleans

var pi = 3.141
var awesome = true

// String interpolation

var score = 85
var str21 = "Your score was \(score)"
var results = "the test result are here: \(str21)"

// Constants

let jack = "sparrow"
print(jack)

// Type annotations

let str11 = "Hello, playground"
let album: String = "Reputation"
let year: Int = 1989
let height: Double = 1.78
let taylorRocks: Bool = true


var finish = "and day"
print(finish)
   
