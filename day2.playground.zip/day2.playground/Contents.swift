import UIKit

// Arrays

let john = "john lennon"
let paul = "paul shelby"
let george = "george edison"
let ringo = "ringo de paul"

let beatles = [john, paul, george, ringo]
beatles [2]

var scores: [Int] = [10, 12, 9]
var singers = ["Taylor", "Adele", "Justin"]

// Sets

let colors = Set(["red", "blue", "green"])
let colors2 = Set(["blue", "red", "green", "red", "green"])
var readings = Set([true, false, true, true])
var attendees = Set([100, 100, 101, 100])

// Tuples

var name = (first: "Taylor", last: "Swift")
name.0
name.first


// Arrays vs sets vs tuples

let address = (house: 555, street: "taylor swift", city: "nashville")

let set = Set(["arrdvark", "astronaut", "azalea"])

let pythons = ["eric", "graham", "johny"]

// Dictionaries

let height = [
    "Taylor Swift" : 1.78, "Ed Sheeran" : 1.76
]
height["Taylor Swift"]


let favoriteIceCream = [ "Paul": "Chocolate",
                         "Sophie": "Vanilla"
]
favoriteIceCream["Paul"]
favoriteIceCream["Karl", default: "Unknown"]


// Creating empty collections

var teams = [String: String]()

var words = Set<String>()
var numbers = Set<Int>()
var scores1 = Dictionary<String, Int>()
var results = Array<Int>()

// Enumerations

let result11 = "failure"
let result12 = "failured"
let result13 = "fail"

enum Result {
    case succes
    case failure
}

let result14 = Result.failure


//Enum associated values

enum Activity {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}

let talking = Activity.talking(topic: "football")

// Enum raw values

enum Planet: Int {
    case mercuryy = 1
    case venus
    case earth
    case mars
}

let earth = Planet(rawValue: 2)
