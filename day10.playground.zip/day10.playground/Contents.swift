import UIKit
import Foundation

//Creating your own classes

class Dog {
    var name: String
    var breq:String
    
    init(name:String, breq:String) {
        self.name = name
        self.breq = breq
    }
}

let poppy = Dog(name: "poppy", breq: "poddle")

//Class inheritance

class Poodle: Dog {
    init(name: String) {
        super.init(name: name, breq: "Poodle")
    }
}

//Overriding methods

class Dog1 {
    func makeNoise() {
        print("Woof!")
    }
}
class Poodle1: Dog1 {
        override func makeNoise() {
            print("Yip!")
        }
    }

let poppy1 = Poodle1()
poppy1.makeNoise()

//Final classes

final class Dog2 {
    var name1: String
    var breed1: String

    init(name1: String, breed1: String) {
        self.name1 = name1
        self.breed1 = breed1
    }
}

// Copying objects

class Singer {
    var name = "Taylor Swift"
}

var singer = Singer()
print(singer.name)

var singerCopy = singer
singerCopy.name = "Justin Bieber"

print(singer.name)

struct Singer1 {
    var name = "Taylor Swift"
}

//Deinitializers

class Person {
    var name = "John Doe"

    init() {
        print("\(name) is alive!")
    }

    func printGreeting() {
        print("Hello, I'm \(name)")
    }
    
    deinit {
        print("\(name) is no more!")
    }
}

for _ in 1...3 {
    let person = Person()
    person.printGreeting()
}

//Mutability

class Singer21 {
    var name = "Taylor Swift"
}

let taylor = Singer21()
taylor.name = "Ed Sheeran"
print(taylor.name)
