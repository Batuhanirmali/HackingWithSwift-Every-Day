import UIKit

//Arithmetic operators

let firstScore = 12
let secondScore = 41

let total = firstScore + secondScore
let difference = firstScore - secondScore
let product = firstScore * secondScore
let divided = firstScore / secondScore
let remainder = 15 % secondScore

//Operator overloading

let meaningOfLife = 42
let doubleMeaning = 42 + 42

let fakers = "fakers gonna"
let actions = fakers + "fake"

let firstHalf = ["john", "paul"]
let secondHalf = ["george", "ringo"]
let beatles = firstHalf + secondHalf

// Compound assignment operators

var score = 95
score -= 5

var quote = "The rain in Spain falls mainly on the"
quote += " Spaniards"

//Comparison operators

let firstScore1 = 6
let secondScore2 = 4

firstScore1 == secondScore2
firstScore1 != secondScore2
firstScore1 < secondScore2
firstScore1 >= secondScore2

//Conditions

let firsCard = 11
let secondCard = 10

if firsCard + secondCard == 2 {
    print("You are lucky")
} else if firsCard + secondCard == 21 {
    print("Blackjack")
} else {
    print("Regular cards")
}

//Combining conditions

let age1 = 12
let age2 = 21

if age1 > 18 && age2 > 18 {
    print("Both are over 18")
}

if age1 > 18 || age2 > 18 {
    print("One of them is over 18")
}

//The ternary operator

let firstCard11 = 11
let secondCard22 = 10
print(firstCard11 == secondCard22 ? "cards are the same" : "cards are different")

if firstCard11 == secondCard22 {
    print("cards are the same")
} else {
    print("cards are different")
}

//Switch statements

let weather = "sunny"

switch weather {
case "rain":
    print("Bring an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear sunscreen")
    fallthrough
default:
    print("Enjoy your day")
}

// Range operators

let examplescore = 80

switch examplescore {
case 0..<50:
    print("bad score")
case 0..<80:
    print("did ok")
default:
    print("great")
}


