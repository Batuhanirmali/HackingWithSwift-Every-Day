//Creating basic closures

import UIKit

let driving = {
    print("I am driving my car")
}

driving ()

//Accepting parameters in a closure

let driving1 = { (place: String) in
    print("I'm going to \(place) in my car")
}
driving1("London")

var cleanRoom = { (name: String) in
    print("I'm cleaning the \(name).")
}
cleanRoom("kitchen")

var click = { (button: Int) in
    if button >= 0 {
        print("Button \(button) was clicked.")
    } else {
        print("That button doesn't exist.")
    }
}

//Returning values from a closure

let driving2 = { (place: String) in
    print("I'm going to \(place) in my car")
}
let drivingWithReturn = { (place: String) -> String in
    return "I'm going to \(place) in my car"
}

let message = drivingWithReturn("London")
print(message)

let measureSize = { (inches: Int) -> String in
    switch inches {
    case 0...26:
        return "XS"
    case 27...30:
        return "S"
    case 31...34:
        return "M"
    case 35...38:
        return "L"
    default:
        return "XL"
    }
}
measureSize(36)

//Closures as parameters

let driving3 = {
    print("I'm driving in my car")
}

func travel(action: () -> Void) {
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}

travel(action: driving)

let awesomeTalk = {
    print("Here's a great talk!")
}
func deliverTalk(name: String, type: () -> Void) {
    print("My talk is called \(name)")
    type()
}
deliverTalk(name: "My Awesome Talk", type: awesomeTalk)

//Trailing closure syntax

func travel3(then: () -> Void) {
    print("I'm getting ready to go.")
    then()
    print("I arrived!")
}
travel3() {
    print("I'm driving in my car")
}
travel3 {
    print("I'm driving in my car")
}

