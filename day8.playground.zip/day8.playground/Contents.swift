import UIKit

//Creating your own structs

struct Sport {
    var name = String()
}

var tennis = Sport (name: "Tennis")

print(tennis.name)

tennis.name = "batu tennis"

//Computed properties

struct Sport11 {
    var name: String
}

struct Sportt {
    var name: String
    var isOlympicSport1: Bool

    var olympicStatus: String {
        if isOlympicSport1 {
            return "\(name) is an Olympic sport"
        } else {
            return "\(name) is not an Olympic sport"
        }
    }
}
let chessBoxing = Sportt(name: "Chessboxing", isOlympicSport1: false)
print(chessBoxing.olympicStatus)

struct Keyboard {
    var isMechanical = false
    var noiseLevel: Int {
        if isMechanical {
            return 11
        } else {
            return 3
        }
    }
}
let majestouch = Keyboard(isMechanical: true)
print(majestouch.noiseLevel)


//Property observers

struct Progress {
    var task: String
    var amount: Int {
        didSet {
            print("\(task) is now \(amount)% complete")
        }
    }
}

var progresss = Progress(task: "Loading data", amount: 0)
progresss.amount = 30
progresss.amount = 80
progresss.amount = 100

struct Game {
    var score: Int {
        didSet {
            print("Your score is now \(score).")
        }
    }
}

//Methods

struct City {
    var population: Int

    func collectTaxes() -> Int {
        return population * 1000
    }
}

let london = City(population: 9_000_000)
london.collectTaxes()

//Mutating methods


struct Person {
    var name: String

    mutating func makeAnonymous() {
        name = "Anonymous"
    }
}

var person = Person(name: "Ed")
person.makeAnonymous()

struct Book {
    var totalPages: Int
    var pagesLeftToRead = 0
    mutating func read(pages: Int) {
        if pages < pagesLeftToRead {
            pagesLeftToRead -= pages
        } else {
            pagesLeftToRead = 0
            print("I'm done!")
        }
    }
}

struct Delorean {
    var speed = 0
    mutating func accelerate() {
        speed += 1
        if speed == 88 {
            travelThroughTime()
        }
    }
    func travelThroughTime() {
        print("Where we're going we don't need roads.")
    }
}

//Properties and methods of strings

let string = "Do or do not, there is no try."
print(string.count)
print(string.hasPrefix("Do"))
print(string.uppercased())
print(string.sorted())

let joke = "What's red and smells like blue paint? Red paint."
joke.count > 10

//Properties and methods of arrays

var toys = ["Woody"]
print(toys.count)
toys.append("Buzz")
toys.firstIndex(of: "Buzz")
print(toys.sorted())
toys.remove(at: 0)

